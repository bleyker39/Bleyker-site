
Bleyker — Blake1.OS (Proyecto Oficial)
Versión: 1.0

Contenido:
- index.html : página principal con banner animado
- styles.css : estilos neón rojo/crema
- script.js  : animaciones y partículas de fondo
- images/logo_bleyker.svg : logo SVG
- README.md : este archivo
- LICENCIA.txt : licencia básica

Instrucciones de publicación en GitHub Pages:
1) Crear repositorio público en GitHub.
2) Subir el contenido del ZIP (descomprimido) a la rama main o a la carpeta /docs.
3) Activar Settings -> Pages -> Source: main / (root) o /docs.
4) Esperar 1-2 minutos y abrir la URL https://TU-USUARIO.github.io/NOMBRE-REPO/ .
