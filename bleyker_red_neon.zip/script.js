
// Banner micro-interaction and simple particles background
document.addEventListener('DOMContentLoaded', function(){
  // Banner hover - small lift
  var banner = document.getElementById('neonBanner');
  if(banner){
    banner.addEventListener('mouseenter', function(){ banner.style.transform = 'translateY(-6px) scale(1.02)'; })
    banner.addEventListener('mouseleave', function(){ banner.style.transform = 'translateY(0) scale(1)'; })
  }

  // Simple canvas particles
  var canvas = document.getElementById('particles');
  if(!canvas) return;
  var ctx = canvas.getContext('2d');
  function resize(){ canvas.width = window.innerWidth; canvas.height = window.innerHeight; }
  window.addEventListener('resize', resize); resize();

  var particles = [];
  for(var i=0;i<70;i++){
    particles.push({
      x: Math.random()*canvas.width,
      y: Math.random()*canvas.height,
      vx: (Math.random()-0.5)*0.4,
      vy: (Math.random()-0.5)*0.4,
      r: Math.random()*1.8+0.6,
      color: (Math.random()>0.6? 'rgba(255,15,0,0.9)':'rgba(255,220,202,0.8)')
    });
  }

  function loop(){
    ctx.clearRect(0,0,canvas.width,canvas.height);
    for(var i=0;i<particles.length;i++){
      var p = particles[i];
      p.x += p.vx; p.y += p.vy;
      if(p.x<0) p.x = canvas.width;
      if(p.x>canvas.width) p.x = 0;
      if(p.y<0) p.y = canvas.height;
      if(p.y>canvas.height) p.y = 0;
      ctx.beginPath();
      ctx.fillStyle = p.color;
      ctx.globalCompositeOperation = 'lighter';
      ctx.arc(p.x,p.y,p.r,0,Math.PI*2);
      ctx.fill();
    }
    requestAnimationFrame(loop);
  }
  loop();
});
