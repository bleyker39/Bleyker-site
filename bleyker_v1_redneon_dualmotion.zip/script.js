
// Efecto de destellos aleatorios en el fondo
setInterval(() => {
  const body = document.body;
  const intensity = Math.random() * 0.4 + 0.6;
  body.style.filter = `brightness(${intensity})`;
}, 500);
